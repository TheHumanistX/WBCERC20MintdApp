import React from 'react'
import { LOGO } from '../assets'

const Header = () => {
  return (
    <div>
        <img src='' />
      <ConnectWallet className='connect-wallet' />
    </div>
  )
}

export default Header
