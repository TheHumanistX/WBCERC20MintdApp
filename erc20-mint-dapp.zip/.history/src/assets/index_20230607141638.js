export { default as bg } from './bg.svg'
export { default as turtlecat } from './turtlecat.png'