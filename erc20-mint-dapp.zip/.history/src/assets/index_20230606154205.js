export { default as bg } from './bg.svg'
export { default as LOGO } from './LOGO.png'