export { default as bg } from './bg.svg'
