export { default as bg } from './bg.svg'
export { default as coin } from './coin.svg'