export { default as bg } from './bg.svg'
export { default as coin } from './coin.png'
export { default as coin2 } from './coin2.svg'